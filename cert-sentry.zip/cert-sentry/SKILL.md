---
name: cert-sentry
version: 1.0.0
display_name: 证书哨兵
display_name_en: cert-sentry
description: 用大白话检查 HTTPS 站点的 TLS 证书健康度、新增或删除监控域名、解读告警并给出 Nginx 证书修复步骤。当用户提到"检查证书""证书快过期""SSL/TLS 到期""nginx 证书不一致""续签没生效""加个域名监控""看证书巡检结果"等场景时应使用本技能。仅检测启用 TLS 的站点（HTTPS），不处理明文 HTTP。
description_zh: 用大白话检查 HTTPS 站点的 TLS 证书健康度，支持新增或删除监控域名、解读告警并给出 Nginx 证书修复步骤。适用于检查证书过期、SSL/TLS 到期、证书链不完整、续签后未 reload 等场景。仅检测启用 TLS 的站点（HTTPS）。
description_en: Check TLS certificate health in plain language, add or remove monitored domains, interpret alerts and give Nginx certificate fix steps. Covers expiry, incomplete chains, and renew-without-reload issues. TLS-enabled sites (HTTPS) only.
agent_created: true
---

# cert-sentry · 证书巡检助手

## Overview

cert-sentry 是一个零第三方依赖的 TLS 证书巡检器，检查四类免费工具不覆盖的故障：证书链完整性、磁盘证书与实际握手证书是否一致、证书指纹留痕、探测失败本身。本技能把它的结果翻译成人话，并处理日常的"加域名 / 看结果 / 排故障"三类请求。

核心事实：证书只存在于 HTTPS（TLS）中，明文 HTTP 无证书可查。因此本技能只处理 TLS 站点，配置里没有也不需要有 http/https 开关。

## 资源

- `scripts/probe.py`：探测脚本本体（Python 3.9+ 标准库 + 系统 `openssl`，无需 pip）。
- `assets/sites.example.json`：站点配置模板，含全部字段与说明。

## 工作目录定位

执行前先确定 `sites.json` 与输出目录：

1. 若当前工作区已有 `cert-sentry/` 目录（含 `sites.json`），以它为项目根，直接用其中的脚本与配置。
2. 否则以本技能目录为根：从 `assets/sites.example.json` 复制出 `sites.json` 放到用户当前工作目录，探测用 `scripts/probe.py`。
3. 绝不猜测用户的域名。列表为空或仍是 `example.com` 时，先问用户要检查哪些域名，再动手。

## 三种任务

### 任务一：检查证书 / 看巡检结果

触发：「帮我检查证书」「看看证书有没有问题」「证书巡检结果」。

步骤：

1. 按"工作目录定位"找到 `sites.json` 与 `probe.py`。
2. 运行：`python3 probe.py --out-dir <临时目录>`（用临时目录避免污染示例数据；用户明确要更新看板时再用项目内的 `data/`）。
3. 读取生成的 `latest.json`，用中文逐站汇报，每站一行：
   - 域名 + 协议列（`tls_version`，如 TLS 1.3；探测失败则显示未握手）。
   - 剩余天数与到期日。
   - 状态：正常 / 注意 / 异常 / 探测失败。
   - 只把有问题的站点展开讲，正常站点一句话带过。
4. 汇总告警数量（P0/P1/P2），先讲最严重的。
5. 全程用大白话，不输出原始 JSON，不堆字段。用户要细节时再展开。

判定口径（与脚本一致）：

| 状态 | 含义 |
| --- | --- |
| 正常 | 证书有效、链完整、到期日充裕 |
| 注意 | 30/14/7 天内到期，或链不完整 |
| 异常 | 已过期 / 校验失败 / Nginx 证书不一致 |
| 探测失败 | 连不上或握手失败，本身就是 P0，不能当作"没问题" |

### 任务二：新增 / 删除 / 修改监控域名

触发：「加个域名监控」「把 xxx.com 加进去」「别盯这个域名了」。

步骤：

1. 找到 `sites.json`，先看现有结构（分组、defaults）。
2. 修改时保持 JSON 合法，沿用已有分组；新域名没有明确归属就放进 `production` 组。
3. 端口默认 443，除非用户指定；证书巡检只走 TLS，不处理 HTTP。
4. 改完把改前改后的差异用一句话说明，并主动跑一次任务一验证新配置能通。
5. 不要在用户确认前删除任何已有域名。

### 任务三：解读告警 / 排障

触发：「这个告警什么意思」「nginx 不一致怎么处理」「续签了还是老的证书」。

按告警码给出对应动作，一次只讲一条，先讲用户当前遇到的那条：

| 告警码 | 级别 | 人话解释 | 处理动作 |
| --- | --- | --- | --- |
| `expired` / `expiring` | P0/P1/P2 | 证书已经或快要到期 | 续签证书（certbot / 云厂商控制台），续签后必须 reload nginx |
| `verify_failed` | P0 | 浏览器可能报"证书不可信" | 检查证书链是否完整、域名是否匹配、证书是否过期 |
| `nginx_cert_mismatch` | P0 | 磁盘上的新证书和 nginx 正在用的不是同一张，多半是续签后没 reload | 在证书所在主机执行 `sudo nginx -t && sudo systemctl reload nginx`，再跑一次巡检确认 |
| `nginx_cert_missing` | P1 | 配置里写的证书路径读不到 | 核对 `ssl_certificate` 路径，确认文件存在且 nginx 用户可读 |
| `chain_incomplete` | P1 | 只发了叶证书、缺中间证书，curl 和部分客户端会报错 | 用 fullchain.pem 作为 `ssl_certificate`，不要只用 cert.pem |
| `unknown_expiry` | P1 | 解析不出到期时间 | 检查证书格式是否为合法 PEM/DER |
| `probe_error` | P0 | 探测失败：连不上或握手失败 | 检查域名解析、防火墙、端口、服务是否在跑；探测失败不能忽略 |

`nginx_cert_mismatch` 是最有价值的一条，也是免费工具不做的一条：它专抓"证书已续签但 nginx 没 reload"这种不会触发任何到期提醒的故障。讲排障时要强调这一点。

## 边界

- 只检测自己拥有或已获授权的主机，不对公网第三方域名批量探测。
- 不实现通用到期提醒、可用性监控、账号体系或计费。
- 看板的"协议"列显示的是握手协商出的 TLS 版本（TLS 1.3 / TLS 1.2），不是 http/https 开关。
- 只读取/修改用户明确指定的配置文件，改动前先说明。
